import React, { useState } from 'react';
import { Phone, Calculator, MessageSquare, MapPin, Mail, Clock, Package, Truck, ShieldCheck, Warehouse, Instagram, Train } from 'lucide-react';
import { motion } from 'framer-motion';
import Modal from 'react-modal';
import logo from './assets/abktrans-logo.png'; // Заменил логотип

Modal.setAppElement('#root');

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [fromCity, setFromCity] = useState('Алматы');
  const [toCity, setToCity] = useState('Актау');
  
  return (
    <div className="bg-white min-h-screen"> {/* Сделал фон белым */}
      <header className="p-4 shadow-md flex justify-between items-center bg-white">
        <img src={logo} alt="ABKTRANS" className="h-12" />
        <nav>
          <ul className="flex space-x-6 text-gray-700">
            <li><a href="#" className="hover:text-blue-500">Главная</a></li>
            <li><a href="#" className="hover:text-blue-500">Услуги</a></li>
            <li><a href="#" className="hover:text-blue-500">Тарифы</a></li>
            <li><a href="#calculator" className="hover:text-blue-500">Калькулятор</a></li>
          </ul>
        </nav>
      </header>
      
      <section id="calculator" className="p-6">
        <h2 className="text-2xl font-bold">Калькулятор</h2>
        <input 
          type="number" 
          className="border p-2 w-full mt-2" 
          placeholder="Введите цифры"
          onChange={(e) => console.log(e.target.value)} // Исправил ввод цифр
        />
      </section>
    </div>
  );
}

export default App;
